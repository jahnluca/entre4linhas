<?php 
    $username = 'root';
    $password = '';
    //cria conexao com banco de dados
    $connection = new PDO( 'mysql:host=localhost;dbname=empresa', $username, $password );
?>